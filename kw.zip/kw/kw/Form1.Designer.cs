﻿namespace kw
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBukiety = new System.Windows.Forms.ListBox();
            this.picBukiet = new System.Windows.Forms.PictureBox();
            this.lblNazwa = new System.Windows.Forms.Label();
            this.lblCena = new System.Windows.Forms.Label();
            this.lblOpis = new System.Windows.Forms.Label();
            this.lblIloscTekst = new System.Windows.Forms.Label();
            this.lblKoszykTekst = new System.Windows.Forms.Label();
            this.lblSuma = new System.Windows.Forms.Label();
            this.listKoszyk = new System.Windows.Forms.ListBox();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnUsun = new System.Windows.Forms.Button();
            this.btnZamow = new System.Windows.Forms.Button();
            this.numIlosc = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.picBukiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIlosc)).BeginInit();
            this.SuspendLayout();
            // 
            // listBukiety
            // 
            this.listBukiety.FormattingEnabled = true;
            this.listBukiety.ItemHeight = 16;
            this.listBukiety.Location = new System.Drawing.Point(285, 124);
            this.listBukiety.Name = "listBukiety";
            this.listBukiety.Size = new System.Drawing.Size(120, 84);
            this.listBukiety.TabIndex = 0;
            this.listBukiety.SelectedIndexChanged += new System.EventHandler(this.listBukiety_SelectedIndexChanged);
            // 
            // picBukiet
            // 
            this.picBukiet.Image = global::kw.Properties.Resources.tulipan;
            this.picBukiet.Location = new System.Drawing.Point(-109, 89);
            this.picBukiet.Name = "picBukiet";
            this.picBukiet.Size = new System.Drawing.Size(370, 747);
            this.picBukiet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picBukiet.TabIndex = 1;
            this.picBukiet.TabStop = false;
            // 
            // lblNazwa
            // 
            this.lblNazwa.AutoSize = true;
            this.lblNazwa.Location = new System.Drawing.Point(281, 104);
            this.lblNazwa.Name = "lblNazwa";
            this.lblNazwa.Size = new System.Drawing.Size(62, 16);
            this.lblNazwa.TabIndex = 2;
            this.lblNazwa.Text = "lblNazwa";
            // 
            // lblCena
            // 
            this.lblCena.AutoSize = true;
            this.lblCena.Location = new System.Drawing.Point(352, 104);
            this.lblCena.Name = "lblCena";
            this.lblCena.Size = new System.Drawing.Size(53, 16);
            this.lblCena.TabIndex = 3;
            this.lblCena.Text = "lblCena";
            // 
            // lblOpis
            // 
            this.lblOpis.AutoSize = true;
            this.lblOpis.Location = new System.Drawing.Point(32, 39);
            this.lblOpis.Name = "lblOpis";
            this.lblOpis.Size = new System.Drawing.Size(49, 16);
            this.lblOpis.TabIndex = 4;
            this.lblOpis.Text = "lblOpis";
            // 
            // lblIloscTekst
            // 
            this.lblIloscTekst.AutoSize = true;
            this.lblIloscTekst.Location = new System.Drawing.Point(444, 132);
            this.lblIloscTekst.Name = "lblIloscTekst";
            this.lblIloscTekst.Size = new System.Drawing.Size(83, 16);
            this.lblIloscTekst.TabIndex = 5;
            this.lblIloscTekst.Text = "lblIloscTekst";
            // 
            // lblKoszykTekst
            // 
            this.lblKoszykTekst.AutoSize = true;
            this.lblKoszykTekst.Location = new System.Drawing.Point(608, 104);
            this.lblKoszykTekst.Name = "lblKoszykTekst";
            this.lblKoszykTekst.Size = new System.Drawing.Size(98, 16);
            this.lblKoszykTekst.TabIndex = 6;
            this.lblKoszykTekst.Text = "lblKoszykTekst";
            // 
            // lblSuma
            // 
            this.lblSuma.AutoSize = true;
            this.lblSuma.Location = new System.Drawing.Point(675, 216);
            this.lblSuma.Name = "lblSuma";
            this.lblSuma.Size = new System.Drawing.Size(56, 16);
            this.lblSuma.TabIndex = 7;
            this.lblSuma.Text = "lblSuma";
            // 
            // listKoszyk
            // 
            this.listKoszyk.FormattingEnabled = true;
            this.listKoszyk.ItemHeight = 16;
            this.listKoszyk.Location = new System.Drawing.Point(611, 124);
            this.listKoszyk.Name = "listKoszyk";
            this.listKoszyk.Size = new System.Drawing.Size(120, 84);
            this.listKoszyk.TabIndex = 8;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(367, 279);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(75, 23);
            this.btnDodaj.TabIndex = 9;
            this.btnDodaj.Text = "btnDodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click_1);
            // 
            // btnUsun
            // 
            this.btnUsun.Location = new System.Drawing.Point(584, 279);
            this.btnUsun.Name = "btnUsun";
            this.btnUsun.Size = new System.Drawing.Size(75, 23);
            this.btnUsun.TabIndex = 10;
            this.btnUsun.Text = "btnUsun";
            this.btnUsun.UseVisualStyleBackColor = true;
            this.btnUsun.Click += new System.EventHandler(this.btnUsun_Click_1);
            // 
            // btnZamow
            // 
            this.btnZamow.Location = new System.Drawing.Point(479, 279);
            this.btnZamow.Name = "btnZamow";
            this.btnZamow.Size = new System.Drawing.Size(75, 23);
            this.btnZamow.TabIndex = 11;
            this.btnZamow.Text = "btnZamow";
            this.btnZamow.UseVisualStyleBackColor = true;
            this.btnZamow.Click += new System.EventHandler(this.btnZamow_Click);
            // 
            // numIlosc
            // 
            this.numIlosc.Location = new System.Drawing.Point(447, 159);
            this.numIlosc.Name = "numIlosc";
            this.numIlosc.Size = new System.Drawing.Size(120, 22);
            this.numIlosc.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numIlosc);
            this.Controls.Add(this.btnZamow);
            this.Controls.Add(this.btnUsun);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.listKoszyk);
            this.Controls.Add(this.lblSuma);
            this.Controls.Add(this.lblKoszykTekst);
            this.Controls.Add(this.lblIloscTekst);
            this.Controls.Add(this.lblOpis);
            this.Controls.Add(this.lblCena);
            this.Controls.Add(this.lblNazwa);
            this.Controls.Add(this.picBukiet);
            this.Controls.Add(this.listBukiety);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBukiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIlosc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBukiety;
        private System.Windows.Forms.PictureBox picBukiet;
        private System.Windows.Forms.Label lblNazwa;
        private System.Windows.Forms.Label lblCena;
        private System.Windows.Forms.Label lblOpis;
        private System.Windows.Forms.Label lblIloscTekst;
        private System.Windows.Forms.Label lblKoszykTekst;
        private System.Windows.Forms.Label lblSuma;
        private System.Windows.Forms.ListBox listKoszyk;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnUsun;
        private System.Windows.Forms.Button btnZamow;
        private System.Windows.Forms.NumericUpDown numIlosc;
    }
}

