﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace kw
{
    public partial class Form1 : Form
    {
        private List<Bukiet> oferta = new List<Bukiet>();
        private List<PozycjaKoszyka> koszyk = new List<PozycjaKoszyka>();

        public Form1()
        {
            InitializeComponent();
            string folder = @"C:\Users\Veronika\source\repos\kw\kw\bin\Debug\images\";

            oferta.Add(new Bukiet
            {
                Nazwa = "Rumianki",
                Cena = 39.99m,
                Opis = "Delikatny bukiet świeżych rumianków",
                SciezkaObrazka = folder + "rumianek.jpg"
            });
            oferta.Add(new Bukiet
            {
                Nazwa = "Róże",
                Cena = 89.99m,
                Opis = "Elegancki bukiet różowych róż",
                SciezkaObrazka = folder + "roza.jpg"
            });
            oferta.Add(new Bukiet
            {
                Nazwa = "Tulipany",
                Cena = 49.99m,
                Opis = "Kolorowy bukiet wiosennych tulipanów",
                SciezkaObrazka = folder + "tulipan.jpg"
            });

            OdswiezListeBukietow();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void OdswiezListeBukietow()
        {
            listBukiety.Items.Clear();
            foreach (var b in oferta)
                listBukiety.Items.Add(b);
        }

        private void listBukiety_SelectedIndexChanged(object sender, EventArgs e)
        {
            var bukiet = listBukiety.SelectedItem as Bukiet;
            if (bukiet == null) return;

            lblNazwa.Text = bukiet.Nazwa;
            lblCena.Text = bukiet.Cena.ToString("C");
            lblOpis.Text = bukiet.Opis;

            // Zwolnij stary obrazek
            if (picBukiet.Image != null)
            {
                picBukiet.Image.Dispose();
                picBukiet.Image = null;
            }

            // Załaduj nowy obrazek do pamięci
            if (File.Exists(bukiet.SciezkaObrazka))
            {
                byte[] bytes = File.ReadAllBytes(bukiet.SciezkaObrazka);
                MemoryStream ms = new MemoryStream(bytes);
                picBukiet.Image = Image.FromStream(ms);
            }
        }

        private void OdswiezKoszyk()
        {
            listKoszyk.Items.Clear();
            foreach (var p in koszyk)
                listKoszyk.Items.Add(p);

            decimal suma = koszyk.Sum(p => p.Wartosc);
            lblSuma.Text = "Suma: " + suma.ToString("C");
        }

        private void btnDodaj_Click_1(object sender, EventArgs e)
        {
            var bukiet = listBukiety.SelectedItem as Bukiet;
            if (bukiet == null)
            {
                MessageBox.Show("Wybierz bukiet.");
                return;
            }
            int ilosc = (int)numIlosc.Value;
            koszyk.Add(new PozycjaKoszyka(bukiet, ilosc));
            OdswiezKoszyk();
        }

        private void btnUsun_Click_1(object sender, EventArgs e)
        {
            if (listKoszyk.SelectedIndex < 0)
            {
                MessageBox.Show("Zaznacz element do usunięcia.");
                return;
            }
            koszyk.RemoveAt(listKoszyk.SelectedIndex);
            OdswiezKoszyk();
        }

        private void btnZamow_Click(object sender, EventArgs e)
        {
            if (koszyk.Count == 0)
            {
                MessageBox.Show("Koszyk jest pusty.");
                return;
            }

            string zamowienie = "ZAMÓWIENIE\n\n";
            foreach (var p in koszyk)
                zamowienie += p.ToString() + "\n";

            zamowienie += "\n" + lblSuma.Text;

            MessageBox.Show(zamowienie, "Potwierdzenie zamówienia");
        }
    }

    public class Bukiet
    {
        public string Nazwa { get; set; }
        public decimal Cena { get; set; }
        public string Opis { get; set; }
        public string SciezkaObrazka { get; set; }

        public override string ToString()
        {
            return Nazwa + " (" + Cena.ToString("C") + ")";
        }
    }

    public class PozycjaKoszyka
    {
        public Bukiet Bukiet { get; set; }
        public int Ilosc { get; set; }

        public decimal Wartosc
        {
            get { return Bukiet.Cena * Ilosc; }
        }

        public PozycjaKoszyka(Bukiet b, int ilosc)
        {
            Bukiet = b;
            Ilosc = ilosc;
        }

        public override string ToString()
        {
            return Bukiet.Nazwa + " x" + Ilosc + " = " + Wartosc.ToString("C");
        }
    }
}